let k=null,z=null,_=0,E=null;const P="floatingPanelPrefs",G=3e4,O=420,R=720,$=340,S=520,a=12,I=18,M=56,X=44;document.addEventListener("contextmenu",e=>{const t=U(e);_=Date.now(),z=t,t&&(k=t)},!0);document.addEventListener("mouseover",e=>{const t=U(e);t&&(k=t)},!0);chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="content:get-last-image"?(n({image:Y()??void 0}),!1):e.type==="content:toggle-floating-panel"?(V().then(n).catch(()=>n({ok:!1})),!0):e.type==="content:open-floating-panel"?(j().then(n).catch(()=>n({ok:!1})),!0):!1);function Y(){return Date.now()-_<=G?z:k}async function V(){return(await W()).toggle(),{ok:!0}}async function j(){return(await W()).open(),{ok:!0}}async function W(){return E||(E=await K()),E}async function K(){const e=await nt(),t=tt(e),n=await q(),i=document.createElement("prompt-reverse-floating-panel"),c=i.attachShadow({mode:"open"}),r=document.createElement("div"),s=document.createElement("section"),o=document.createElement("div"),l=document.createElement("span"),h=document.createElement("div"),p=document.createElement("button"),f=document.createElement("button"),w=document.createElement("iframe"),y=document.createElement("div"),m=document.createElement("button"),x=document.createElement("img"),N=document.createElement("span"),C=document.createElement("style");i.setAttribute("aria-live","polite"),r.className="floating-frame",s.className="floating-panel",o.className="floating-dragbar",l.className="floating-grab-lip",h.className="floating-actions",p.className="floating-icon-button",f.className="floating-icon-button",w.className="floating-iframe",y.className="floating-resize-handle",m.className="floating-collapsed-button",x.className="floating-collapsed-icon",N.className="floating-collapsed-dot",p.type="button",p.setAttribute("aria-label","折叠浮窗"),p.textContent="–",f.type="button",f.setAttribute("aria-label","关闭浮窗"),f.textContent="×",m.type="button",m.setAttribute("aria-label","展开 AI Prompt Reverse Engineer 浮窗"),x.alt="",x.src=chrome.runtime.getURL("icons/icon-32.png"),w.title="AI Prompt Reverse Engineer",w.src=J(n),C.textContent=lt,h.append(p,f),o.append(l,h),s.append(o,w,y),m.append(x,N),r.append(s,m),c.append(C,r),et().appendChild(i);let u;const D=()=>u.clampToViewport();return u=new Z(i,r,o,y,m,n,t,()=>{window.removeEventListener("resize",D),E=null}),F(p),F(f),p.addEventListener("click",g=>{g.preventDefault(),g.stopPropagation(),u.collapse()}),f.addEventListener("click",g=>{g.preventDefault(),g.stopPropagation(),u.close()}),m.addEventListener("click",()=>u.expand()),r.addEventListener("keydown",g=>{g.key==="Escape"&&(g.preventDefault(),u.collapse())}),window.addEventListener("resize",D),u.open(),u}function F(e){e.addEventListener("pointerdown",t=>{t.stopPropagation()})}async function q(){try{return(await B({type:"panel:create-workspace",surface:"floating",title:Q()})).id}catch{return}}function J(e){const t=new URLSearchParams({surface:"floating"});return e&&t.set("workspaceId",e),chrome.runtime.getURL(`sidepanel.html?${t.toString()}`)}function Q(){const e=document.title.trim();return e?`浮窗 · ${e.slice(0,24)}`:"浮窗"}async function B(e){const t=await chrome.runtime.sendMessage(e);if(!t?.ok)throw new Error(t?.error?.message??"Runtime message failed.");return t.data}class Z{constructor(t,n,i,c,r,s,o,l){this.host=t,this.frame=n,this.dragBar=i,this.resizeHandle=c,this.collapsedButton=r,this.workspaceId=s,this.onClose=l,this.state=o,this.frame.tabIndex=-1,this.dragBar.addEventListener("pointerdown",h=>this.startDrag(h)),this.resizeHandle.addEventListener("pointerdown",h=>this.startResize(h)),this.render()}hidden=!0;isClosed=!1;isDetaching=!1;state;toggle(){if(this.hidden){this.open();return}if(this.state.collapsed){this.expand();return}this.collapse()}open(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),b(this.state)}expand(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),b(this.state)}collapse(){this.hidden=!1,this.state.collapsed=!0,this.render(),this.collapsedButton.focus({preventScroll:!0}),b(this.state)}hide(){this.hidden=!0,this.render()}close(){this.isClosed||(this.isClosed=!0,this.hidden=!0,this.host.remove(),this.onClose())}clampToViewport(){this.state=H(this.state),this.render(),b(this.state)}startDrag(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.dragBar.setPointerCapture(t.pointerId);const n=t.clientX,i=t.clientY,c=this.state.left,r=this.state.top,s=l=>{this.state.left=d(c+l.clientX-n,a,Math.max(a,window.innerWidth-this.state.width-a)),this.state.top=d(r+l.clientY-i,a,Math.max(a,window.innerHeight-this.state.height-a)),this.render()},o=l=>{this.dragBar.removeEventListener("pointermove",s),this.dragBar.removeEventListener("pointerup",o),this.dragBar.removeEventListener("pointercancel",o),b(this.state),l.type==="pointerup"&&this.detachIfNearViewportEdge()};this.dragBar.addEventListener("pointermove",s),this.dragBar.addEventListener("pointerup",o),this.dragBar.addEventListener("pointercancel",o)}async detachIfNearViewportEdge(){if(!(!this.workspaceId||this.isClosed||this.isDetaching||!this.isNearDetachEdge())){this.isDetaching=!0;try{await B({type:"panel:detach-workspace",workspaceId:this.workspaceId}),this.close()}catch{this.isDetaching=!1}}}isNearDetachEdge(){return this.state.left<=I||this.state.top<=I||this.state.left+this.state.width>=window.innerWidth-I}startResize(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.resizeHandle.setPointerCapture(t.pointerId);const n=t.clientX,i=t.clientY,c=this.state.width,r=this.state.height,s=l=>{const h=Math.max(v(),window.innerWidth-this.state.left-a),p=Math.max(A(),Math.min(L(),window.innerHeight-this.state.top-a));this.state.width=d(c+l.clientX-n,v(),h),this.state.height=d(r+l.clientY-i,S,p),this.render()},o=()=>{this.resizeHandle.removeEventListener("pointermove",s),this.resizeHandle.removeEventListener("pointerup",o),this.resizeHandle.removeEventListener("pointercancel",o),b(this.state)};this.resizeHandle.addEventListener("pointermove",s),this.resizeHandle.addEventListener("pointerup",o),this.resizeHandle.addEventListener("pointercancel",o)}render(){const t=H(this.state);if(this.state=t,this.host.style.display=this.hidden?"none":"block",!this.hidden){if(t.collapsed){const n=d(t.left+t.width-M,a,Math.max(a,window.innerWidth-M-a));this.host.style.left=`${n}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${M}px`,this.host.style.height=`${X}px`,this.frame.dataset.state="collapsed";return}this.host.style.left=`${t.left}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${t.width}px`,this.host.style.height=`${t.height}px`,this.frame.dataset.state="open"}}}function tt(e){const t=d(Math.round(e.width??Math.min(O,window.innerWidth-a*2)),v(),T()),n=d(Math.round(e.height??Math.min(R,window.innerHeight-a*2)),A(),L()),i=window.innerWidth-t-18,c=Math.max(18,Math.round((window.innerHeight-n)*.32));return H({left:Math.round(e.left??i),top:Math.round(e.top??c),width:t,height:n,collapsed:!!e.collapsed})}function H(e){const t=v(),n=A(),i=T(),c=L(),r=d(Math.round(e.width),t,i),s=d(Math.round(e.height),n,c);return{width:r,height:s,left:d(Math.round(e.left),a,Math.max(a,window.innerWidth-r-a)),top:d(Math.round(e.top),a,Math.max(a,window.innerHeight-s-a)),collapsed:e.collapsed}}function v(){return Math.min($,T())}function T(){return Math.max(240,window.innerWidth-a*2)}function A(){return Math.min(S,L())}function L(){return Math.max(320,window.innerHeight-a*2)}function et(){return document.body??document.documentElement}function nt(){return new Promise(e=>{chrome.storage.local.get(P,t=>{const n=t[P];e(it(n)?n:{})})})}function b(e){return new Promise(t=>{chrome.storage.local.set({[P]:e},()=>t())})}function it(e){return typeof e=="object"&&e!==null}function d(e,t,n){return Math.min(Math.max(e,t),n)}function U(e){const t=e.composedPath()[0],n=t instanceof Element?t:null;if(!n)return null;const i=at(n);return i?{url:st(i),sourcePageUrl:window.location.href,sourceTitle:document.title}:null}function at(e){const t=e.closest("img");if(t instanceof HTMLImageElement)return t.currentSrc||t.src||t.getAttribute("data-src")||t.getAttribute("data-original")||t.getAttribute("data-lazy-src");const n=e.closest("image");if(n instanceof SVGImageElement)return n.href.baseVal||n.getAttribute("href")||n.getAttribute("xlink:href");const i=ot(e);return i||null}function ot(e){let t=e;for(;t&&t!==document.documentElement;){const n=window.getComputedStyle(t),i=rt(n.backgroundImage);if(i)return i;t=t.parentElement}return null}function rt(e){return!e||e==="none"?null:/url\((['"]?)(.*?)\1\)/.exec(e)?.[2]||null}function st(e){if(e.startsWith("data:image/"))return e;try{return new URL(e,window.location.href).href}catch{return e}}const lt=`
  :host {
    position: fixed;
    z-index: 2147483647;
    display: none;
    box-sizing: border-box;
    pointer-events: none;
    color-scheme: light;
    font-family:
      "Microsoft YaHei UI", "PingFang SC", "HarmonyOS Sans SC", "Segoe UI",
      ui-sans-serif, sans-serif;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  .floating-frame {
    position: absolute;
    inset: 0;
    pointer-events: auto;
  }

  .floating-frame:focus {
    outline: 0;
  }

  .floating-panel {
    position: absolute;
    inset: 0;
    display: grid;
    grid-template-rows: 28px minmax(0, 1fr);
    overflow: hidden;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 10px;
    background:
      linear-gradient(180deg, rgba(255, 254, 250, 0.96), rgba(246, 245, 238, 0.96)),
      #fffdf8;
    box-shadow:
      0 20px 54px rgba(23, 32, 28, 0.2),
      0 3px 12px rgba(23, 32, 28, 0.08);
    backdrop-filter: blur(16px);
  }

  .floating-dragbar {
    position: relative;
    min-height: 28px;
    border-bottom: 1px solid rgba(23, 32, 28, 0.08);
    background:
      linear-gradient(90deg, rgba(10, 122, 112, 0.08), transparent 52%),
      rgba(255, 253, 248, 0.92);
    cursor: grab;
    user-select: none;
  }

  .floating-dragbar:active {
    cursor: grabbing;
  }

  .floating-grab-lip {
    position: absolute;
    left: 50%;
    top: 11px;
    width: 44px;
    height: 4px;
    transform: translateX(-50%);
    border-radius: 999px;
    background: rgba(23, 32, 28, 0.22);
  }

  .floating-actions {
    position: absolute;
    top: 3px;
    right: 4px;
    display: inline-flex;
    gap: 4px;
  }

  .floating-icon-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.1);
    border-radius: 7px;
    background: rgba(255, 254, 250, 0.78);
    color: #17201c;
    cursor: pointer;
    font: 900 15px/1 "Segoe UI", sans-serif;
  }

  .floating-icon-button:hover,
  .floating-icon-button:focus-visible {
    border-color: rgba(10, 122, 112, 0.36);
    background: #ffffff;
    color: #075e56;
    outline: 0;
  }

  .floating-iframe {
    width: 100%;
    min-width: 0;
    height: 100%;
    border: 0;
    background: #f5f4ef;
  }

  .floating-resize-handle {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 18px;
    height: 18px;
    cursor: nwse-resize;
  }

  .floating-resize-handle::after {
    position: absolute;
    right: 4px;
    bottom: 4px;
    width: 8px;
    height: 8px;
    border-right: 2px solid rgba(10, 122, 112, 0.42);
    border-bottom: 2px solid rgba(10, 122, 112, 0.42);
    content: "";
  }

  .floating-collapsed-button {
    position: absolute;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    width: 56px;
    height: 44px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 999px;
    background:
      linear-gradient(135deg, rgba(255, 255, 255, 0.38), transparent 40%),
      linear-gradient(135deg, #17201c, #0a7a70 60%, #c8923a);
    box-shadow: 0 12px 30px rgba(23, 32, 28, 0.22);
    cursor: pointer;
  }

  .floating-collapsed-button:focus-visible {
    outline: 0;
    box-shadow:
      0 12px 30px rgba(23, 32, 28, 0.22),
      0 0 0 3px rgba(10, 122, 112, 0.22);
  }

  .floating-collapsed-icon {
    width: 24px;
    height: 24px;
    border-radius: 7px;
  }

  .floating-collapsed-dot {
    position: absolute;
    right: 10px;
    top: 9px;
    width: 8px;
    height: 8px;
    border: 1px solid rgba(255, 255, 255, 0.68);
    border-radius: 999px;
    background: #58d5c8;
  }

  .floating-frame[data-state="collapsed"] .floating-panel {
    display: none;
  }

  .floating-frame[data-state="collapsed"] .floating-collapsed-button {
    display: inline-flex;
  }
`;
