let I=null,v=null;const y="floatingPanelPrefs",S=420,B=720,W=340,N=520,i=12,L=56,_=44;document.addEventListener("contextmenu",e=>{const t=F(e);t&&(I=t)},!0);document.addEventListener("mouseover",e=>{const t=F(e);t&&(I=t)},!0);chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="content:get-last-image"?(n({image:I??void 0}),!1):e.type==="content:toggle-floating-panel"?(C().then(n).catch(()=>n({ok:!1})),!0):e.type==="content:open-floating-panel"?(D().then(n).catch(()=>n({ok:!1})),!0):!1);async function C(){return(await T()).toggle(),{ok:!0}}async function D(){return(await T()).open(),{ok:!0}}async function T(){return v||(v=await U()),v}async function U(){const e=await $(),t=O(e),n=document.createElement("prompt-reverse-floating-panel"),a=n.attachShadow({mode:"open"}),r=document.createElement("div"),l=document.createElement("section"),s=document.createElement("div"),o=document.createElement("span"),c=document.createElement("div"),h=document.createElement("button"),p=document.createElement("button"),m=document.createElement("iframe"),E=document.createElement("div"),u=document.createElement("button"),b=document.createElement("img"),k=document.createElement("span"),A=document.createElement("style");n.setAttribute("aria-live","polite"),r.className="floating-frame",l.className="floating-panel",s.className="floating-dragbar",o.className="floating-grab-lip",c.className="floating-actions",h.className="floating-icon-button",p.className="floating-icon-button",m.className="floating-iframe",E.className="floating-resize-handle",u.className="floating-collapsed-button",b.className="floating-collapsed-icon",k.className="floating-collapsed-dot",h.type="button",h.setAttribute("aria-label","折叠浮窗"),h.textContent="–",p.type="button",p.setAttribute("aria-label","关闭浮窗"),p.textContent="×",u.type="button",u.setAttribute("aria-label","展开 AI Prompt Reverse Engineer 浮窗"),b.alt="",b.src=chrome.runtime.getURL("icons/icon-32.png"),m.title="AI Prompt Reverse Engineer",m.src=chrome.runtime.getURL("sidepanel.html?surface=floating"),A.textContent=q,c.append(h,p),s.append(o,c),l.append(s,m,E),u.append(b,k),r.append(l,u),a.append(A,r),Y().appendChild(n);const g=new G(n,r,s,E,u,t);return h.addEventListener("click",()=>g.collapse()),p.addEventListener("click",()=>g.hide()),u.addEventListener("click",()=>g.expand()),r.addEventListener("keydown",z=>{z.key==="Escape"&&(z.preventDefault(),g.collapse())}),window.addEventListener("resize",()=>g.clampToViewport()),g.open(),g}class G{constructor(t,n,a,r,l,s){this.host=t,this.frame=n,this.dragBar=a,this.resizeHandle=r,this.collapsedButton=l,this.state=s,this.frame.tabIndex=-1,this.dragBar.addEventListener("pointerdown",o=>this.startDrag(o)),this.resizeHandle.addEventListener("pointerdown",o=>this.startResize(o)),this.render()}hidden=!0;state;toggle(){if(this.hidden){this.open();return}if(this.state.collapsed){this.expand();return}this.collapse()}open(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),f(this.state)}expand(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),f(this.state)}collapse(){this.hidden=!1,this.state.collapsed=!0,this.render(),this.collapsedButton.focus({preventScroll:!0}),f(this.state)}hide(){this.hidden=!0,this.render()}clampToViewport(){this.state=M(this.state),this.render(),f(this.state)}startDrag(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.dragBar.setPointerCapture(t.pointerId);const n=t.clientX,a=t.clientY,r=this.state.left,l=this.state.top,s=c=>{this.state.left=d(r+c.clientX-n,i,Math.max(i,window.innerWidth-this.state.width-i)),this.state.top=d(l+c.clientY-a,i,Math.max(i,window.innerHeight-this.state.height-i)),this.render()},o=()=>{this.dragBar.removeEventListener("pointermove",s),this.dragBar.removeEventListener("pointerup",o),this.dragBar.removeEventListener("pointercancel",o),f(this.state)};this.dragBar.addEventListener("pointermove",s),this.dragBar.addEventListener("pointerup",o),this.dragBar.addEventListener("pointercancel",o)}startResize(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.resizeHandle.setPointerCapture(t.pointerId);const n=t.clientX,a=t.clientY,r=this.state.width,l=this.state.height,s=c=>{const h=Math.max(x(),window.innerWidth-this.state.left-i),p=Math.max(H(),Math.min(w(),window.innerHeight-this.state.top-i));this.state.width=d(r+c.clientX-n,x(),h),this.state.height=d(l+c.clientY-a,N,p),this.render()},o=()=>{this.resizeHandle.removeEventListener("pointermove",s),this.resizeHandle.removeEventListener("pointerup",o),this.resizeHandle.removeEventListener("pointercancel",o),f(this.state)};this.resizeHandle.addEventListener("pointermove",s),this.resizeHandle.addEventListener("pointerup",o),this.resizeHandle.addEventListener("pointercancel",o)}render(){const t=M(this.state);if(this.state=t,this.host.style.display=this.hidden?"none":"block",!this.hidden){if(t.collapsed){const n=d(t.left+t.width-L,i,Math.max(i,window.innerWidth-L-i));this.host.style.left=`${n}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${L}px`,this.host.style.height=`${_}px`,this.frame.dataset.state="collapsed";return}this.host.style.left=`${t.left}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${t.width}px`,this.host.style.height=`${t.height}px`,this.frame.dataset.state="open"}}}function O(e){const t=d(Math.round(e.width??Math.min(S,window.innerWidth-i*2)),x(),P()),n=d(Math.round(e.height??Math.min(B,window.innerHeight-i*2)),H(),w()),a=window.innerWidth-t-18,r=Math.max(18,Math.round((window.innerHeight-n)*.32));return M({left:Math.round(e.left??a),top:Math.round(e.top??r),width:t,height:n,collapsed:!!e.collapsed})}function M(e){const t=x(),n=H(),a=P(),r=w(),l=d(Math.round(e.width),t,a),s=d(Math.round(e.height),n,r);return{width:l,height:s,left:d(Math.round(e.left),i,Math.max(i,window.innerWidth-l-i)),top:d(Math.round(e.top),i,Math.max(i,window.innerHeight-s-i)),collapsed:e.collapsed}}function x(){return Math.min(W,P())}function P(){return Math.max(240,window.innerWidth-i*2)}function H(){return Math.min(N,w())}function w(){return Math.max(320,window.innerHeight-i*2)}function Y(){return document.body??document.documentElement}function $(){return new Promise(e=>{chrome.storage.local.get(y,t=>{const n=t[y];e(X(n)?n:{})})})}function f(e){return new Promise(t=>{chrome.storage.local.set({[y]:e},()=>t())})}function X(e){return typeof e=="object"&&e!==null}function d(e,t,n){return Math.min(Math.max(e,t),n)}function F(e){const t=e.composedPath()[0],n=t instanceof Element?t:null;if(!n)return null;const a=R(n);return a?{url:K(a),sourcePageUrl:window.location.href,sourceTitle:document.title}:null}function R(e){const t=e.closest("img");if(t instanceof HTMLImageElement)return t.currentSrc||t.src||t.getAttribute("data-src")||t.getAttribute("data-original")||t.getAttribute("data-lazy-src");const n=e.closest("image");if(n instanceof SVGImageElement)return n.href.baseVal||n.getAttribute("href")||n.getAttribute("xlink:href");const a=V(e);return a||null}function V(e){let t=e;for(;t&&t!==document.documentElement;){const n=window.getComputedStyle(t),a=j(n.backgroundImage);if(a)return a;t=t.parentElement}return null}function j(e){return!e||e==="none"?null:/url\((['"]?)(.*?)\1\)/.exec(e)?.[2]||null}function K(e){if(e.startsWith("data:image/"))return e;try{return new URL(e,window.location.href).href}catch{return e}}const q=`
  :host {
    position: fixed;
    z-index: 2147483647;
    display: none;
    box-sizing: border-box;
    pointer-events: none;
    color-scheme: light;
    font-family:
      "Microsoft YaHei UI", "PingFang SC", "HarmonyOS Sans SC", "Segoe UI",
      ui-sans-serif, sans-serif;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  .floating-frame {
    position: absolute;
    inset: 0;
    pointer-events: auto;
  }

  .floating-frame:focus {
    outline: 0;
  }

  .floating-panel {
    position: absolute;
    inset: 0;
    display: grid;
    grid-template-rows: 28px minmax(0, 1fr);
    overflow: hidden;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 10px;
    background:
      linear-gradient(180deg, rgba(255, 254, 250, 0.96), rgba(246, 245, 238, 0.96)),
      #fffdf8;
    box-shadow:
      0 20px 54px rgba(23, 32, 28, 0.2),
      0 3px 12px rgba(23, 32, 28, 0.08);
    backdrop-filter: blur(16px);
  }

  .floating-dragbar {
    position: relative;
    min-height: 28px;
    border-bottom: 1px solid rgba(23, 32, 28, 0.08);
    background:
      linear-gradient(90deg, rgba(10, 122, 112, 0.08), transparent 52%),
      rgba(255, 253, 248, 0.92);
    cursor: grab;
    user-select: none;
  }

  .floating-dragbar:active {
    cursor: grabbing;
  }

  .floating-grab-lip {
    position: absolute;
    left: 50%;
    top: 11px;
    width: 44px;
    height: 4px;
    transform: translateX(-50%);
    border-radius: 999px;
    background: rgba(23, 32, 28, 0.22);
  }

  .floating-actions {
    position: absolute;
    top: 3px;
    right: 4px;
    display: inline-flex;
    gap: 4px;
  }

  .floating-icon-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.1);
    border-radius: 7px;
    background: rgba(255, 254, 250, 0.78);
    color: #17201c;
    cursor: pointer;
    font: 900 15px/1 "Segoe UI", sans-serif;
  }

  .floating-icon-button:hover,
  .floating-icon-button:focus-visible {
    border-color: rgba(10, 122, 112, 0.36);
    background: #ffffff;
    color: #075e56;
    outline: 0;
  }

  .floating-iframe {
    width: 100%;
    min-width: 0;
    height: 100%;
    border: 0;
    background: #f5f4ef;
  }

  .floating-resize-handle {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 18px;
    height: 18px;
    cursor: nwse-resize;
  }

  .floating-resize-handle::after {
    position: absolute;
    right: 4px;
    bottom: 4px;
    width: 8px;
    height: 8px;
    border-right: 2px solid rgba(10, 122, 112, 0.42);
    border-bottom: 2px solid rgba(10, 122, 112, 0.42);
    content: "";
  }

  .floating-collapsed-button {
    position: absolute;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    width: 56px;
    height: 44px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 999px;
    background:
      linear-gradient(135deg, rgba(255, 255, 255, 0.38), transparent 40%),
      linear-gradient(135deg, #17201c, #0a7a70 60%, #c8923a);
    box-shadow: 0 12px 30px rgba(23, 32, 28, 0.22);
    cursor: pointer;
  }

  .floating-collapsed-button:focus-visible {
    outline: 0;
    box-shadow:
      0 12px 30px rgba(23, 32, 28, 0.22),
      0 0 0 3px rgba(10, 122, 112, 0.22);
  }

  .floating-collapsed-icon {
    width: 24px;
    height: 24px;
    border-radius: 7px;
  }

  .floating-collapsed-dot {
    position: absolute;
    right: 10px;
    top: 9px;
    width: 8px;
    height: 8px;
    border: 1px solid rgba(255, 255, 255, 0.68);
    border-radius: 999px;
    background: #58d5c8;
  }

  .floating-frame[data-state="collapsed"] .floating-panel {
    display: none;
  }

  .floating-frame[data-state="collapsed"] .floating-collapsed-button {
    display: inline-flex;
  }
`;
