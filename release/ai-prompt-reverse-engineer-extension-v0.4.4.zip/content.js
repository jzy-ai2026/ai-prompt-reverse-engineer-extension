let I=null,N=null,F=0,w=null;const M="floatingPanelPrefs",D=3e4,W=420,U=720,G=340,_=520,i=12,y=56,O=44;document.addEventListener("contextmenu",e=>{const t=B(e);F=Date.now(),N=t,t&&(I=t)},!0);document.addEventListener("mouseover",e=>{const t=B(e);t&&(I=t)},!0);chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="content:get-last-image"?(n({image:X()??void 0}),!1):e.type==="content:toggle-floating-panel"?(Y().then(n).catch(()=>n({ok:!1})),!0):e.type==="content:open-floating-panel"?($().then(n).catch(()=>n({ok:!1})),!0):!1);function X(){return Date.now()-F<=D?N:I}async function Y(){return(await S()).toggle(),{ok:!0}}async function $(){return(await S()).open(),{ok:!0}}async function S(){return w||(w=await R()),w}async function R(){const e=await q(),t=j(e),n=document.createElement("prompt-reverse-floating-panel"),o=n.attachShadow({mode:"open"}),a=document.createElement("div"),d=document.createElement("section"),r=document.createElement("div"),s=document.createElement("span"),l=document.createElement("div"),h=document.createElement("button"),p=document.createElement("button"),b=document.createElement("iframe"),L=document.createElement("div"),f=document.createElement("button"),x=document.createElement("img"),T=document.createElement("span"),z=document.createElement("style");n.setAttribute("aria-live","polite"),a.className="floating-frame",d.className="floating-panel",r.className="floating-dragbar",s.className="floating-grab-lip",l.className="floating-actions",h.className="floating-icon-button",p.className="floating-icon-button",b.className="floating-iframe",L.className="floating-resize-handle",f.className="floating-collapsed-button",x.className="floating-collapsed-icon",T.className="floating-collapsed-dot",h.type="button",h.setAttribute("aria-label","折叠浮窗"),h.textContent="–",p.type="button",p.setAttribute("aria-label","关闭浮窗"),p.textContent="×",f.type="button",f.setAttribute("aria-label","展开 AI Prompt Reverse Engineer 浮窗"),x.alt="",x.src=chrome.runtime.getURL("icons/icon-32.png"),b.title="AI Prompt Reverse Engineer",b.src=chrome.runtime.getURL("sidepanel.html?surface=floating"),z.textContent=nt,l.append(h,p),r.append(s,l),d.append(r,b,L),f.append(x,T),a.append(d,f),o.append(z,a),K().appendChild(n);let u;const C=()=>u.clampToViewport();return u=new V(n,a,r,L,f,t,()=>{window.removeEventListener("resize",C),w=null}),k(h),k(p),h.addEventListener("click",g=>{g.preventDefault(),g.stopPropagation(),u.collapse()}),p.addEventListener("click",g=>{g.preventDefault(),g.stopPropagation(),u.close()}),f.addEventListener("click",()=>u.expand()),a.addEventListener("keydown",g=>{g.key==="Escape"&&(g.preventDefault(),u.collapse())}),window.addEventListener("resize",C),u.open(),u}function k(e){e.addEventListener("pointerdown",t=>{t.stopPropagation()})}class V{constructor(t,n,o,a,d,r,s){this.host=t,this.frame=n,this.dragBar=o,this.resizeHandle=a,this.collapsedButton=d,this.onClose=s,this.state=r,this.frame.tabIndex=-1,this.dragBar.addEventListener("pointerdown",l=>this.startDrag(l)),this.resizeHandle.addEventListener("pointerdown",l=>this.startResize(l)),this.render()}hidden=!0;isClosed=!1;state;toggle(){if(this.hidden){this.open();return}if(this.state.collapsed){this.expand();return}this.collapse()}open(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),m(this.state)}expand(){this.hidden=!1,this.state.collapsed=!1,this.render(),this.frame.focus({preventScroll:!0}),m(this.state)}collapse(){this.hidden=!1,this.state.collapsed=!0,this.render(),this.collapsedButton.focus({preventScroll:!0}),m(this.state)}hide(){this.hidden=!0,this.render()}close(){this.isClosed||(this.isClosed=!0,this.hidden=!0,this.host.remove(),this.onClose())}clampToViewport(){this.state=P(this.state),this.render(),m(this.state)}startDrag(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.dragBar.setPointerCapture(t.pointerId);const n=t.clientX,o=t.clientY,a=this.state.left,d=this.state.top,r=l=>{this.state.left=c(a+l.clientX-n,i,Math.max(i,window.innerWidth-this.state.width-i)),this.state.top=c(d+l.clientY-o,i,Math.max(i,window.innerHeight-this.state.height-i)),this.render()},s=()=>{this.dragBar.removeEventListener("pointermove",r),this.dragBar.removeEventListener("pointerup",s),this.dragBar.removeEventListener("pointercancel",s),m(this.state)};this.dragBar.addEventListener("pointermove",r),this.dragBar.addEventListener("pointerup",s),this.dragBar.addEventListener("pointercancel",s)}startResize(t){if(t.button!==0||this.state.collapsed)return;t.preventDefault(),this.resizeHandle.setPointerCapture(t.pointerId);const n=t.clientX,o=t.clientY,a=this.state.width,d=this.state.height,r=l=>{const h=Math.max(E(),window.innerWidth-this.state.left-i),p=Math.max(A(),Math.min(v(),window.innerHeight-this.state.top-i));this.state.width=c(a+l.clientX-n,E(),h),this.state.height=c(d+l.clientY-o,_,p),this.render()},s=()=>{this.resizeHandle.removeEventListener("pointermove",r),this.resizeHandle.removeEventListener("pointerup",s),this.resizeHandle.removeEventListener("pointercancel",s),m(this.state)};this.resizeHandle.addEventListener("pointermove",r),this.resizeHandle.addEventListener("pointerup",s),this.resizeHandle.addEventListener("pointercancel",s)}render(){const t=P(this.state);if(this.state=t,this.host.style.display=this.hidden?"none":"block",!this.hidden){if(t.collapsed){const n=c(t.left+t.width-y,i,Math.max(i,window.innerWidth-y-i));this.host.style.left=`${n}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${y}px`,this.host.style.height=`${O}px`,this.frame.dataset.state="collapsed";return}this.host.style.left=`${t.left}px`,this.host.style.top=`${t.top}px`,this.host.style.width=`${t.width}px`,this.host.style.height=`${t.height}px`,this.frame.dataset.state="open"}}}function j(e){const t=c(Math.round(e.width??Math.min(W,window.innerWidth-i*2)),E(),H()),n=c(Math.round(e.height??Math.min(U,window.innerHeight-i*2)),A(),v()),o=window.innerWidth-t-18,a=Math.max(18,Math.round((window.innerHeight-n)*.32));return P({left:Math.round(e.left??o),top:Math.round(e.top??a),width:t,height:n,collapsed:!!e.collapsed})}function P(e){const t=E(),n=A(),o=H(),a=v(),d=c(Math.round(e.width),t,o),r=c(Math.round(e.height),n,a);return{width:d,height:r,left:c(Math.round(e.left),i,Math.max(i,window.innerWidth-d-i)),top:c(Math.round(e.top),i,Math.max(i,window.innerHeight-r-i)),collapsed:e.collapsed}}function E(){return Math.min(G,H())}function H(){return Math.max(240,window.innerWidth-i*2)}function A(){return Math.min(_,v())}function v(){return Math.max(320,window.innerHeight-i*2)}function K(){return document.body??document.documentElement}function q(){return new Promise(e=>{chrome.storage.local.get(M,t=>{const n=t[M];e(J(n)?n:{})})})}function m(e){return new Promise(t=>{chrome.storage.local.set({[M]:e},()=>t())})}function J(e){return typeof e=="object"&&e!==null}function c(e,t,n){return Math.min(Math.max(e,t),n)}function B(e){const t=e.composedPath()[0],n=t instanceof Element?t:null;if(!n)return null;const o=Q(n);return o?{url:et(o),sourcePageUrl:window.location.href,sourceTitle:document.title}:null}function Q(e){const t=e.closest("img");if(t instanceof HTMLImageElement)return t.currentSrc||t.src||t.getAttribute("data-src")||t.getAttribute("data-original")||t.getAttribute("data-lazy-src");const n=e.closest("image");if(n instanceof SVGImageElement)return n.href.baseVal||n.getAttribute("href")||n.getAttribute("xlink:href");const o=Z(e);return o||null}function Z(e){let t=e;for(;t&&t!==document.documentElement;){const n=window.getComputedStyle(t),o=tt(n.backgroundImage);if(o)return o;t=t.parentElement}return null}function tt(e){return!e||e==="none"?null:/url\((['"]?)(.*?)\1\)/.exec(e)?.[2]||null}function et(e){if(e.startsWith("data:image/"))return e;try{return new URL(e,window.location.href).href}catch{return e}}const nt=`
  :host {
    position: fixed;
    z-index: 2147483647;
    display: none;
    box-sizing: border-box;
    pointer-events: none;
    color-scheme: light;
    font-family:
      "Microsoft YaHei UI", "PingFang SC", "HarmonyOS Sans SC", "Segoe UI",
      ui-sans-serif, sans-serif;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  .floating-frame {
    position: absolute;
    inset: 0;
    pointer-events: auto;
  }

  .floating-frame:focus {
    outline: 0;
  }

  .floating-panel {
    position: absolute;
    inset: 0;
    display: grid;
    grid-template-rows: 28px minmax(0, 1fr);
    overflow: hidden;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 10px;
    background:
      linear-gradient(180deg, rgba(255, 254, 250, 0.96), rgba(246, 245, 238, 0.96)),
      #fffdf8;
    box-shadow:
      0 20px 54px rgba(23, 32, 28, 0.2),
      0 3px 12px rgba(23, 32, 28, 0.08);
    backdrop-filter: blur(16px);
  }

  .floating-dragbar {
    position: relative;
    min-height: 28px;
    border-bottom: 1px solid rgba(23, 32, 28, 0.08);
    background:
      linear-gradient(90deg, rgba(10, 122, 112, 0.08), transparent 52%),
      rgba(255, 253, 248, 0.92);
    cursor: grab;
    user-select: none;
  }

  .floating-dragbar:active {
    cursor: grabbing;
  }

  .floating-grab-lip {
    position: absolute;
    left: 50%;
    top: 11px;
    width: 44px;
    height: 4px;
    transform: translateX(-50%);
    border-radius: 999px;
    background: rgba(23, 32, 28, 0.22);
  }

  .floating-actions {
    position: absolute;
    top: 3px;
    right: 4px;
    display: inline-flex;
    gap: 4px;
  }

  .floating-icon-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.1);
    border-radius: 7px;
    background: rgba(255, 254, 250, 0.78);
    color: #17201c;
    cursor: pointer;
    font: 900 15px/1 "Segoe UI", sans-serif;
  }

  .floating-icon-button:hover,
  .floating-icon-button:focus-visible {
    border-color: rgba(10, 122, 112, 0.36);
    background: #ffffff;
    color: #075e56;
    outline: 0;
  }

  .floating-iframe {
    width: 100%;
    min-width: 0;
    height: 100%;
    border: 0;
    background: #f5f4ef;
  }

  .floating-resize-handle {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 18px;
    height: 18px;
    cursor: nwse-resize;
  }

  .floating-resize-handle::after {
    position: absolute;
    right: 4px;
    bottom: 4px;
    width: 8px;
    height: 8px;
    border-right: 2px solid rgba(10, 122, 112, 0.42);
    border-bottom: 2px solid rgba(10, 122, 112, 0.42);
    content: "";
  }

  .floating-collapsed-button {
    position: absolute;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    width: 56px;
    height: 44px;
    padding: 0;
    border: 1px solid rgba(23, 32, 28, 0.13);
    border-radius: 999px;
    background:
      linear-gradient(135deg, rgba(255, 255, 255, 0.38), transparent 40%),
      linear-gradient(135deg, #17201c, #0a7a70 60%, #c8923a);
    box-shadow: 0 12px 30px rgba(23, 32, 28, 0.22);
    cursor: pointer;
  }

  .floating-collapsed-button:focus-visible {
    outline: 0;
    box-shadow:
      0 12px 30px rgba(23, 32, 28, 0.22),
      0 0 0 3px rgba(10, 122, 112, 0.22);
  }

  .floating-collapsed-icon {
    width: 24px;
    height: 24px;
    border-radius: 7px;
  }

  .floating-collapsed-dot {
    position: absolute;
    right: 10px;
    top: 9px;
    width: 8px;
    height: 8px;
    border: 1px solid rgba(255, 255, 255, 0.68);
    border-radius: 999px;
    background: #58d5c8;
  }

  .floating-frame[data-state="collapsed"] .floating-panel {
    display: none;
  }

  .floating-frame[data-state="collapsed"] .floating-collapsed-button {
    display: inline-flex;
  }
`;
